/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.Service;

import gestionbiblio.Util.DataBase;
import gestionbiblio.entities.commande;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author moham
 */
public class commandeService {
    private final Connection connexion;
    private Statement ste;

       
       public commandeService() {
       connexion=DataBase.getInstance().getConnexion();
    }
       public void ajoutercommande(commande l) throws SQLException {
        String req = "INSERT INTO `commande` (`nomlivre`,`nbp`,`dateC`) VALUES ( ?, ?, ?) ";
        PreparedStatement pstm = connexion.prepareStatement(req);
        pstm.setString(1, l.getNomlivre());
        pstm.setInt(2, l.getNbp());
        pstm.setString(3, l.getDateC());
        pstm.executeUpdate();
        
    }
       List<commande> getAllcommande() throws SQLException {
        List<commande> commande = new ArrayList<>();
        String req = "select * from commande";
        Statement stm = connexion.createStatement();
        ResultSet result =  stm.executeQuery(req);    
        while(result.next()){
            commande l = new commande(result.getString("nomlivre"),result.getInt("nbp"),result.getString("dateC"));
            commande.add(l);
        }
        
        return commande;
    }
    
    public boolean updatecommande(commande c) throws SQLException {
        String sql = "UPDATE commande SET nomlivre=?, nbp=?, dateC=? WHERE id=?";

        PreparedStatement statement = connexion.prepareStatement(sql);
        statement.setString(1, c.getNomlivre());
        statement.setInt(2, c.getNbp());
        statement.setString(3, c.getDateC());
        statement.setInt(4, c.getId());
        int rowsUpdated = statement.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("An existing product was updated successfully!");
        }
        return true;
    }
    public boolean deletecommande(commande c) throws SQLException {
        PreparedStatement pre = connexion.prepareStatement("DELETE FROM commande where id =?");
        pre.setInt(1, c.getId());
        pre.executeUpdate();
        int rowsDeleted = pre.executeUpdate();
        if (rowsDeleted > 0) {
            System.out.println("A book was deleted successfully!");
        }
        return true;
    }
    public List<commande> readAll() throws SQLException {
        List<commande> arr = new ArrayList<>();
        ste = connexion.createStatement();
        ResultSet rs = ste.executeQuery("select * from commande");
        while (rs.next()) {
            int id = rs.getInt(1);
            String nomlivre = rs.getString("nomlivre");
            int nbp = rs.getInt("nbp");
            String dateC = rs.getString("dateC");
            
           
            commande l = new commande(id, nomlivre, nbp, dateC);
            arr.add(l);
        }
        return arr;
    }
    
}

