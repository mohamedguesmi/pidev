/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.Service;

import gestionbiblio.Util.DataBase;
import gestionbiblio.entities.Panier;
import gestionbiblio.entities.User;
import gestionbiblio.entities.livre;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author moham
 */
public class livreService {
    private final Connection connexion;
    private Statement ste;

       
       public livreService() {
       connexion=DataBase.getInstance().getConnexion();
    }
       public void ajouterlivre(livre l) throws SQLException {
        String req = "INSERT INTO `livre` (`nomlivre`, `auteurlivre`, `prixlivre`,`contenu`,`quantitelivre`,`imageLivre`) VALUES ( ?, ?, ?,?,?,?) ";
        PreparedStatement pstm = connexion.prepareStatement(req);
        pstm.setString(1, l.getNomlivre());
        pstm.setString(2, l.getAuteurlivre());
        pstm.setInt(3, l.getPrixlivre());
        pstm.setString(4, l.getContenu());
        pstm.setInt(5, l.getQuantitelivre());
        pstm.setString(6, l.getImageLivre());
        pstm.executeUpdate();
    }
       List<livre> getAlllivre() throws SQLException {
        List<livre> livre = new ArrayList<>();
        String req = "select * from livre";
        Statement stm = connexion.createStatement();
        ResultSet result =  stm.executeQuery(req);    
        while(result.next()){
            livre l = new livre(result.getString("nomlivre"), result.getString("auteurlivre"),result.getInt("prixlivre"),result.getString("contenu"),result.getInt("quantitelivre"));
            livre.add(l);
        }
        
        return livre;
    }
    
    public boolean updatelivre(livre l) throws SQLException {
        String sql = "UPDATE livre SET nomlivre=?, auteurlivre=?, prixlivre=?, contenu=?, quantitelivre=? WHERE id=?";

        PreparedStatement statement = connexion.prepareStatement(sql);
        statement.setString(1, l.getNomlivre());
        statement.setString(2, l.getAuteurlivre());
        statement.setInt(3, l.getPrixlivre());
        statement.setString(4, l.getContenu());
        statement.setInt(5, l.getQuantitelivre());
        statement.setInt(6, l.getId());
        int rowsUpdated = statement.executeUpdate();
        if (rowsUpdated > 0) {
            System.out.println("An existing product was updated successfully!");
        }
        return true;
    }
    public boolean deleteClasse(livre l) throws SQLException {
        PreparedStatement pre = connexion.prepareStatement("DELETE FROM livre where id =?");
        pre.setInt(1, l.getId());
        pre.executeUpdate();
        int rowsDeleted = pre.executeUpdate();
        if (rowsDeleted > 0) {
            System.out.println("A book was deleted successfully!");
        }
        return true;
    }
    public List<livre> readAll() throws SQLException {
        List<livre> arr = new ArrayList<>();
        ste = connexion.createStatement();
        ResultSet rs = ste.executeQuery("select * from livre");
        while (rs.next()) {
            int id = rs.getInt(1);
            String nomlivre = rs.getString("nomlivre");
            String auteurlivre = rs.getString("auteurlivre");
            int prixlivre = rs.getInt("prixlivre");
            String contenu = rs.getString("contenu");
            int quantitelivre = rs.getInt("quantitelivre");
            String img = rs.getString("imageLivre");
            livre l = new livre(id, nomlivre, auteurlivre, prixlivre,contenu,quantitelivre,img);
            arr.add(l);
        }
        return arr;
    }
    public void commander(livre l,User u){
        
        
        String req = "INSERT INTO `elearning`.`panier` ( `prix`, `livre`, `user`) VALUES ( ?, ? , ?)";
        PreparedStatement pstm;
        try {
            pstm = connexion.prepareStatement(req);
            pstm.setInt(1, l.getPrixlivre());
            
            pstm.setInt(2, l.getId());
            System.out.println("Id="+l.getId());
            pstm.setInt(3, u.getId());
            
            pstm.executeUpdate();
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }
        
        
    }
     public List<Panier> readAllFromPanier() throws SQLException {
        List<Panier> arr = new ArrayList<>();
        System.out.println("Serviceeeeeeeee");
        ste = connexion.createStatement();
        ResultSet rs = ste.executeQuery("select * from panier");
        while (rs.next()) {
            int id = rs.getInt(1);
            int livre = rs.getInt("livre");
            int prixlivre = rs.getInt("prix");
            int user = rs.getInt("user");
            User us=new User(user);
            livre liv=getLivre(livre);
            //livre liv=new livre(livre);
            
            Panier l = new Panier(id,liv,us, prixlivre);
            System.out.println(l.toString());
            arr.add(l);
        }
        return arr;
    }
  public livre getLivre(int id) throws SQLException {
        livre arr = new livre();
       // System.out.println("Livre");
        ste = connexion.createStatement();
        ResultSet rs = ste.executeQuery("select * from livre WHERE id="+id);
        while (rs.next()) {
            
            String nomlivre = rs.getString("nomlivre");
            String auteurlivre = rs.getString("auteurlivre");
            int prixlivre = rs.getInt("prixlivre");
            String contenu = rs.getString("contenu");
            int quantitelivre = rs.getInt("quantitelivre");
            String img = rs.getString("imageLivre");
            arr= new livre(id, nomlivre, auteurlivre, prixlivre,contenu,quantitelivre,img);
            
        }
        return arr;
    }
}
