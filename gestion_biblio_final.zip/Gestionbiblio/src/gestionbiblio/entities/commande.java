/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.entities;

import java.util.Date;
import java.util.Objects;

/**
 *
 * @author ASUS
 */
public class commande {

   
    private int id;
    private String nomlivre;
    private int nbp;
    private String dateC;

    public commande(String nomlivre, int nbp, String dateC) {
        this.nomlivre = nomlivre;
        this.nbp = nbp;
        this.dateC = dateC;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 67 * hash + this.id;
        hash = 67 * hash + Objects.hashCode(this.nomlivre);
        hash = 67 * hash + this.nbp;
        hash = 67 * hash + Objects.hashCode(this.dateC);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final commande other = (commande) obj;
        if (this.id != other.id) {
            return false;
        }
        if (this.nbp != other.nbp) {
            return false;
        }
        if (!Objects.equals(this.nomlivre, other.nomlivre)) {
            return false;
        }
        if (!Objects.equals(this.dateC, other.dateC)) {
            return false;
        }
        return true;
    }

   

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomlivre() {
        return nomlivre;
    }

    public void setNomlivre(String nomlivre) {
        this.nomlivre = nomlivre;
    }

    public int getNbp() {
        return nbp;
    }

    public void setNbp(int nbp) {
        this.nbp = nbp;
    }

    public String getDateC() {
        return dateC;
    }

    public void setDateC(String dateC) {
        this.dateC = dateC;
    }

    public commande(int id, String nomlivre, int nbp, String dateC) {
        this.id = id;
        this.nomlivre = nomlivre;
        this.nbp = nbp;
        this.dateC = dateC;
    }
}
   // private String image_name;
