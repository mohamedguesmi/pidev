/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.entities;

import javafx.scene.image.ImageView;

/**
 *
 * @author ASUS
 */
public class Images {
    private ImageView im;

    public Images() {
    }

    public Images(ImageView im) {
        this.im = im;
    }

    
    
    
    public ImageView getIm() {
        return im;
    }

    public void setIm(ImageView im) {
        this.im = im;
    }
    
    
    
    
}
