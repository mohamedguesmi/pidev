/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.entities;
import java.io.Serializable;
import java.util.Objects;
import javafx.scene.image.ImageView;

/**
 *
 * @author ASUS
 */
public class livre implements Serializable{

   
      private int id;
    private String nomlivre;
    private String auteurlivre;
    private int prixlivre;
    private String contenu;
    private int quantitelivre;
    private String imageLivre;
    // private ImageView im;

    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.id;
        hash = 97 * hash + Objects.hashCode(this.nomlivre);
        hash = 97 * hash + Objects.hashCode(this.auteurlivre);
        hash = 97 * hash + this.prixlivre;
        hash = 97 * hash + Objects.hashCode(this.contenu);
        hash = 97 * hash + this.quantitelivre;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final livre other = (livre) obj;
        if (this.id != other.id) {
            return false;
        }
        if (this.prixlivre != other.prixlivre) {
            return false;
        }
        if (this.quantitelivre != other.quantitelivre) {
            return false;
        }
        if (!Objects.equals(this.nomlivre, other.nomlivre)) {
            return false;
        }
        if (!Objects.equals(this.auteurlivre, other.auteurlivre)) {
            return false;
        }
        if (!Objects.equals(this.contenu, other.contenu)) {
            return false;
        }
        return true;
    }

    public livre(int id, String nomlivre, String auteurlivre, int prixlivre, String contenu, int quantitelivre) {
        this.id = id;
        this.nomlivre = nomlivre;
        this.auteurlivre = auteurlivre;
        this.prixlivre = prixlivre;
        this.contenu = contenu;
        this.quantitelivre = quantitelivre;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNomlivre() {
        return nomlivre;
    }

    public void setNomlivre(String nomlivre) {
        this.nomlivre = nomlivre;
    }

    public String getAuteurlivre() {
        return auteurlivre;
    }

    public void setAuteurlivre(String auteurlivre) {
        this.auteurlivre = auteurlivre;
    }

    public int getPrixlivre() {
        return prixlivre;
    }

    public void setPrixlivre(int prixlivre) {
        this.prixlivre = prixlivre;
    }

    public String getContenu() {
        return contenu;
    }

    public void setContenu(String contenu) {
        this.contenu = contenu;
    }

    public int getQuantitelivre() {
        return quantitelivre;
    }

    public void setQuantitelivre(int quantitelivre) {
        this.quantitelivre = quantitelivre;
    }

    public String getImageLivre() {
        return imageLivre;
    }

    public void setImageLivre(String imageLivre) {
        this.imageLivre = imageLivre;
    }

    public livre() {
    }

    
    

    
    public livre(int id, String nomlivre, String auteurlivre, int prixlivre, String contenu, int quantitelivre, String image_name) {
        this.id = id;
        this.nomlivre = nomlivre;
        this.auteurlivre = auteurlivre;
        this.prixlivre = prixlivre;
        this.contenu = contenu;
        this.quantitelivre = quantitelivre;
        this.imageLivre = image_name;
    }

    public livre(String nomlivre, String auteurlivre, int prixlivre, String contenu, int quantitelivre, String image_name) {
        this.nomlivre = nomlivre;
        this.auteurlivre = auteurlivre;
        this.prixlivre = prixlivre;
        this.contenu = contenu;
        this.quantitelivre = quantitelivre;
        this.imageLivre = image_name;
    }
    

    public livre(String nomlivre, String auteurlivre, int prixlivre, String contenu, int quantitelivre) {
        this.nomlivre = nomlivre;
        this.auteurlivre = auteurlivre;
        this.prixlivre = prixlivre;
        this.contenu = contenu;
        this.quantitelivre = quantitelivre;
    }

    public livre(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return ""+nomlivre;
    }
/*
    public ImageView getIm() {
        return im;
    }

    public void setIm(ImageView im) {
        this.im = im;
    }

    public livre(int id, String nomlivre, String auteurlivre, int prixlivre, String contenu, int quantitelivre, String imageLivre, ImageView im) {
        this.id = id;
        this.nomlivre = nomlivre;
        this.auteurlivre = auteurlivre;
        this.prixlivre = prixlivre;
        this.contenu = contenu;
        this.quantitelivre = quantitelivre;
        this.imageLivre = imageLivre;
        this.im = im;
    }

    public livre(String nomlivre, String auteurlivre, int prixlivre, String contenu, int quantitelivre, String imageLivre, ImageView im) {
        this.nomlivre = nomlivre;
        this.auteurlivre = auteurlivre;
        this.prixlivre = prixlivre;
        this.contenu = contenu;
        this.quantitelivre = quantitelivre;
        this.imageLivre = imageLivre;
        this.im = im;
    }
    
*/
    
    

}