/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.views;

import gestionbiblio.Service.livreService;
import gestionbiblio.entities.livre;
import javafx.scene.image.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Window;
import javax.imageio.ImageIO;

/**
 * FXML Controller class
 *
 * @author ASUS
 */

public class AjouterlivreController implements Initializable {

    @FXML
    private TextField nomL;
    @FXML
    private TextField nomA;
    @FXML
    private TextField prix;
    @FXML
    private TextField con;
    @FXML
    private TextField qte;
    @FXML
    private Button k;
    @FXML
    private Button r;
    @FXML
    private TextField image;
     FileChooser file=new FileChooser();
    @FXML
    private VBox vbMenu;
    String extension="";
  
  /**
     * Initializes the controller class.
     
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        k.setOnAction(e-> {
            //Local(String nom, String adresse, float prix,float surface,int capacite)
            Alert alert = new Alert(Alert.AlertType.WARNING);
            
            alert.setTitle("Error");
            Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
            
            alert.setTitle("Success");
            
            String n= nomL.getText();
            String nb=nomA.getText();
            String ne= prix.getText();
            String nc= con.getText();
            String nz= qte.getText();
            String img= image.getText()+"."+extension;
            
            String ch="";
            Boolean ok =true;
            int pr = -1;
            int pr1= -1;
            int test=Integer.parseInt(ne);
            int test1=Integer.parseInt(nz);
            if(!n.matches("^[a-zA-Z]+$")){
                ch+="Vous devez entrer un nom valide!\n";
                ok=false;
            }
            if(!ne.matches("\\d+")||ne.length()==0){
                ch+="Vous devez entrer un prix valide!\n";
                ok=false;
            }
            if(!nb.matches("^[a-zA-Z]+$")){
                ch+="Vous devez entrer un nom d auteur valide\n";
                ok=false;
            }if(!nz.matches("\\d+")||nz.length()==0){
                ch+="Vous devez entrer une quantite valide\n";
                ok=false;
            }
            else {
                pr = Integer.parseInt(ne);
                pr1=Integer.parseInt(nz);
            }
            if(ok==true){
                livre livre1 = new livre(n,nb,pr,nc,pr1,img);
                livreService cs = new livreService();
                try {
                    cs.ajouterlivre(livre1);
                    ch+="Ajout effectué avec success!\n";
                    alert1.setContentText(ch);
                    alert1.show();
                    
                } catch (SQLException ex) {
                    Logger.getLogger(AjouterlivreController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else {
                alert.setContentText(ch);
                alert.show();
            }
        });
        r.setOnAction(e->{  
            Parent root ;
         try {
             root=FXMLLoader.load(getClass().getResource("Gestionlivre.fxml"));
             r.getScene().setRoot(root);
         } catch (IOException ex) {
             Logger.getLogger(ModifierlivreController.class.getName()).log(Level.SEVERE, null, ex);
         }
            
             });  
    }  
      @FXML
    private void choisir(ActionEvent event){
        
         List<String> extentions=new ArrayList<>();
        extentions.add("*.png");
        extentions.add("*.jpeg");
        extentions.add("*.jpg");
         Window stage = vbMenu.getScene().getWindow();
        file.setTitle("");
        file.getExtensionFilters().add(new FileChooser.ExtensionFilter("Fichier Image",extentions));
        
       File file2=file.showOpenDialog(stage);
       
        
    if(file2 != null)
    {
        image.setText(generateUniqueFileName());
         extension =file2.getName().substring(file2.getName().lastIndexOf(".")+1);
         System.out.println("exten"+extension);
         
        image.setText(generateUniqueFileName());
        System.out.println("------>"+image.getText());
        
        System.out.println(file2.getName());
        BufferedImage bImage;
        //fileLocation.setText(generateUniqueFileName()+);
            try {
                bImage = ImageIO.read(file2);
                ImageIO.write(bImage, extension, new File("C:\\Users\\ASUS\\Dropbox\\Mon PC (DESKTOP-0AI8GMK)\\Documents\\NetBeansProjects\\Gestionbiblio\\src\\gestionbiblio\\images\\"+image.getText()+"."+extension));
            } catch (IOException ex) {
                System.out.println(ex.getMessage());;
            }


    }
    
       
    }
    
   public static void saveToFile(Image image) {
    File outputFile = new File("C:\\Users\\ASUS\\Dropbox\\Mon PC (DESKTOP-0AI8GMK)\\Documents\\NetBeansProjects\\Gestionbiblio\\src\\gestionbiblio\\images\\");
        BufferedImage bImage = SwingFXUtils.fromFXImage(image, null);
    try {
        ImageIO.write(bImage, "png", outputFile);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

   
      String generateUniqueFileName() {
    String filename = "fe";
    //long millis = System.currentTimeMillis();
    String datetime = new Date(System.currentTimeMillis()).toGMTString();
    datetime = datetime.replace(" ", "");
    datetime = datetime.replace(":", "");
    String rndchars =""+Math.random();
    rndchars=rndchars.replace(".", "fe");
    filename = rndchars + "_" + datetime ;
    return filename;
}
   
    
}
