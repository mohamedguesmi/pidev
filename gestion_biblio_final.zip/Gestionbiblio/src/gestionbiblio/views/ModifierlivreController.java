/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.views;

import gestionbiblio.Service.livreService;
import gestionbiblio.entities.livre;
import gestionbiblio.views.GestionlivreController;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class ModifierlivreController implements Initializable {

    @FXML
    private Button r;
    @FXML
    private Button v;
    @FXML
    private TextField noml;
    @FXML
    private TextField noma;
    @FXML
    private TextField prix;
    @FXML
    private TextField cont;
    @FXML
    private TextField qte;
    private static livre cr;
/**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
               GestionlivreController glc = new GestionlivreController();
        livre lvr= glc.getL();
        noml.setText(lvr.getNomlivre());
        noma.setText(lvr.getAuteurlivre());
        prix.setText(String.valueOf(lvr.getPrixlivre()));
        cont.setText(lvr.getAuteurlivre());
        qte.setText(String.valueOf(lvr.getQuantitelivre()));

         r.setOnAction(e->{  
            Parent root ;
         try {
             root=FXMLLoader.load(getClass().getResource("GestionCours.fxml"));
             r.getScene().setRoot(root);
         } catch (IOException ex) {
             Logger.getLogger(ModifierlivreController.class.getName()).log(Level.SEVERE, null, ex);
         }
            
             });  
         v.setOnAction(e->{
         Alert alert = new Alert(Alert.AlertType.WARNING);

                alert.setTitle("Error");
                  
         Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);

                alert.setTitle("Error");
                 
         String nl= noml.getText();
         String na=noma.getText();
         String prx= prix.getText();
         String cnt= cont.getText();
         String qt= qte.getText();

         String ch="";
         Boolean ok =true;
         int pr = -1;
         int pr1= -1;
         int test=Integer.parseInt(prx);
         int test1=Integer.parseInt(qt);
         if(!nl.matches("^[a-zA-Z]+$")){
             ch+="Vous devez entrer un nom valide!\n";
             ok=false;
         }
         if(!na.matches("^[a-zA-Z]+$")){
             ch+="Vous devez entrer un nom d'auteur valide!\n";
             ok=false;
         }
         if(!prx.matches("\\d+")||prx.length()==0||test>100){
             ch+="Vous devez entrer un prix valide heures\n";
             ok=false;
         }
          if(!cnt.matches("^[a-zA-Z]+$")){
             ch+="Vous devez entrer une quantite valide\n";
             ok=false;
         }
           if(!qt.matches("\\d+")||qt.length()==0||test>33000){
             ch+="Vous devez entrer une \n";
             ok=false;
         }
         else {
               pr = Integer.parseInt(prx);
               pr1= Integer.parseInt(qt);
           }
           
           
         if(ok==true){
             
             livre livre1 = new livre(nl, na, pr,cnt,pr1);
             livre1.setId(lvr.getId());
             livreService cs = new livreService();
             try {
                 cs.updatelivre(livre1);
                 ch+="Modification effectué avec success!\n";
                alert1.setContentText(ch);
                alert1.show();
             } catch (SQLException ex) {
                 Logger.getLogger(ModifierlivreController.class.getName()).log(Level.SEVERE, null, ex);
             }
         }
         else {
             alert.setContentText(ch);
                alert.show();
         }
        });
          r.setOnAction(e->{  
            Parent root ;
         try {
             root=FXMLLoader.load(getClass().getResource("Gestionlivre.fxml"));
             r.getScene().setRoot(root);
         } catch (IOException ex) {
             Logger.getLogger(ModifierlivreController.class.getName()).log(Level.SEVERE, null, ex);
         }
            
             });  

         
    }    
    public livre getL() {
        return cr;
}
}
