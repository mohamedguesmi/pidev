/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.views;

import gestionbiblio.Service.commandeService;
import gestionbiblio.entities.commande;
import gestionbiblio.entities.commande;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class GestioncommandeController implements Initializable {

    @FXML
    private Button AjouterC;
    @FXML
    private Button AfficherC;
    @FXML
    private Button ModifierC;
    @FXML
    private TableView<commande> table;
    @FXML
    private TableColumn<commande, String> noml;
    @FXML
    private TableColumn<commande, Integer> nbp;
    @FXML
    private TableColumn<commande, String> dateC;
   
    @FXML
    private Button SupprimerC;
    private static commande cr;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        commandeService cs= new commandeService(); 
        ArrayList<commande> commande= new ArrayList<commande>();
        try {
            commande = (ArrayList<commande>) cs.readAll();
        } catch (SQLException ex) {
            Logger.getLogger(GestioncommandeController.class.getName()).log(Level.SEVERE, null, ex);
        }
        ObservableList<commande> obs = FXCollections.observableArrayList(commande);
        table.setItems(obs);
        noml.setCellValueFactory(new PropertyValueFactory<>("nomlivre"));
        nbp.setCellValueFactory(new PropertyValueFactory<>("nbp"));
        dateC.setCellValueFactory(new PropertyValueFactory<>("dateC"));
        AjouterC.setOnAction(e -> {
            //(String id,String nom, String adresse, String prix, String surface,String capacite)

            try {
                Parent root;
                root = FXMLLoader.load(getClass().getResource("Ajoutercommande.fxml"));
                AjouterC.getScene().setRoot(root);

            } catch (IOException ex) {
                Logger.getLogger(AjoutercommandeController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
            SupprimerC.setOnAction(e -> {
            cr = table.getSelectionModel().getSelectedItem();
                if(cr != null)
                {
                cr = table.getSelectionModel().getSelectedItem();
                    try {
                        cs.deletecommande(cr);
                        Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
                         alert1.setContentText("Suppression effectuée avec succès!");
                           alert1.show();
                           
                    } catch (SQLException ex) {
                        Logger.getLogger(GestioncommandeController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                commandeService cr5= new commandeService(); 
        ArrayList<commande> cla5= new ArrayList<commande>();
        try {
            cla5 = (ArrayList<commande>) cr5.readAll();
        } catch (SQLException ex) {
            Logger.getLogger(GestioncommandeController.class.getName()).log(Level.SEVERE, null, ex);
        }
        ObservableList<commande> obs5 = FXCollections.observableArrayList(cla5);
       
        table.setItems(obs5);
        noml.setCellValueFactory(new PropertyValueFactory<>("nomlivre"));
        nbp.setCellValueFactory(new PropertyValueFactory<>("nbp"));
        dateC.setCellValueFactory(new PropertyValueFactory<>("dateC"));
        
                }
                   });

       
        ModifierC.setOnAction(e -> {
            //(String id,String nom, String adresse, String prix, String surface,String capacite)

            cr = table.getSelectionModel().getSelectedItem();
            if (!(cr == null)) {
                try {
                    Parent root;
                    root = FXMLLoader.load(getClass().getResource("Modifiercommande.fxml"));
                    ModifierC.getScene().setRoot(root);
                } catch (IOException ex) {
                    Logger.getLogger(GestioncommandeController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
       
        
        
    }  
    
     public commande getL() {
        return cr;
}
}
