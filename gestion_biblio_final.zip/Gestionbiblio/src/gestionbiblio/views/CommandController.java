/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.views;


import gestionbiblio.Service.livreService;
import gestionbiblio.entities.User;
import gestionbiblio.entities.livre;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.awt.Color;
import java.awt.Graphics2D;
import java.io.IOException;
import java.util.EnumMap;
import java.util.Map;
import javafx.embed.swing.SwingFXUtils;
import javax.imageio.ImageIO;


/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class CommandController implements Initializable {

    @FXML
    private Button r;
    @FXML
    private TextField nomL;
    @FXML
    private TextField nbp;
    @FXML
    private Button a;
    @FXML
    private ImageView image;
    public static livre l=new livre();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        l=IUserController.getL();
        nomL.setText(l.getNomlivre());
        File file = new File("C:\\Users\\ASUS\\Dropbox\\Mon PC (DESKTOP-0AI8GMK)\\Documents\\NetBeansProjects\\Gestionbiblio\\src\\gestionbiblio\\images\\"+l.getImageLivre());
        image.setImage(new Image(file.toURI().toString()));
        System.out.print(l);
        // TODO
    }    

    @FXML
    private void retour(ActionEvent event) {
         try {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("IUser.fxml"));
        //
        Parent root1 = (Parent) fxmlLoader.load();
                    Stage stage = new Stage();
        stage.setScene(new Scene(root1));  
        stage.show();
        
    } catch(Exception e) {
        e.printStackTrace();
    }
    }

    @FXML
    private void valider(ActionEvent event) {
        livreService cs= new livreService(); 
                User u=new User(1);
                
          
        cs.commander(l, u);
        qrCode();
        
            try {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("panier.fxml"));
        //
        Parent root1 = (Parent) fxmlLoader.load();
                    Stage stage = new Stage();
        stage.setScene(new Scene(root1));  
        stage.show();
        
    } catch(Exception e) {
        e.printStackTrace();
    }
        
         
    }
    public void qrCode(){
       String myCodeText = "https://crunchify.com";
        String filePath = "C:\\Users\\ASUS\\Dropbox\\Mon PC (DESKTOP-0AI8GMK)\\Documents\\NetBeansProjects\\Gestionbiblio\\src\\gestionbiblio\\images\\QC\\"+"Crunchify.com-QRCode"+Math.random()+".png";
        int size = 512;
        String crunchifyFileType = "png";
        File crunchifyFile = new File(filePath);
        try {
 
            Map<EncodeHintType, Object> crunchifyHintType = new EnumMap<EncodeHintType, Object>(EncodeHintType.class);
            crunchifyHintType.put(EncodeHintType.CHARACTER_SET, "UTF-8");
 
            // Now with version 3.4.1 you could change margin (white border size)
            crunchifyHintType.put(EncodeHintType.MARGIN, 1); /* default = 4 */
            Object put = crunchifyHintType.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H);
 
            QRCodeWriter mYQRCodeWriter = new QRCodeWriter(); // throws com.google.zxing.WriterException
            BitMatrix crunchifyBitMatrix = mYQRCodeWriter.encode(myCodeText, BarcodeFormat.QR_CODE, size,
                    size, crunchifyHintType);
            int CrunchifyWidth = crunchifyBitMatrix.getWidth();
 
            // The BufferedImage subclass describes an Image with an accessible buffer of crunchifyImage data.
            BufferedImage crunchifyImage = new BufferedImage(CrunchifyWidth, CrunchifyWidth,
                    BufferedImage.TYPE_INT_RGB);
 
            // Creates a Graphics2D, which can be used to draw into this BufferedImage.
            crunchifyImage.createGraphics();
 
            // This Graphics2D class extends the Graphics class to provide more sophisticated control over geometry, coordinate transformations, color management, and text layout.
            // This is the fundamental class for rendering 2-dimensional shapes, text and images on the Java(tm) platform.
            Graphics2D crunchifyGraphics = (Graphics2D) crunchifyImage.getGraphics();
 
            // setColor() sets this graphics context's current color to the specified color.
            // All subsequent graphics operations using this graphics context use this specified color.
            crunchifyGraphics.setColor(Color.white);
 
            // fillRect() fills the specified rectangle. The left and right edges of the rectangle are at x and x + width - 1.
            crunchifyGraphics.fillRect(0, 0, CrunchifyWidth, CrunchifyWidth);
 
            // TODO: Please change this color as per your need
            crunchifyGraphics.setColor(Color.BLUE);
 
            for (int i = 0; i < CrunchifyWidth; i++) {
                for (int j = 0; j < CrunchifyWidth; j++) {
                    if (crunchifyBitMatrix.get(i, j)) {
                        crunchifyGraphics.fillRect(i, j, 1, 1);
                    }
                }
            }
 
            // A class containing static convenience methods for locating
            // ImageReaders and ImageWriters, and performing simple encoding and decoding.
            ImageIO.write(crunchifyImage, crunchifyFileType, crunchifyFile);
 
            System.out.println("\nCongratulation.. You have successfully created QR Code.. \n" +
                    "Check your code here: " + filePath);
        } catch (WriterException e) {
            System.out.println("\nSorry.. Something went wrong...\n");
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
