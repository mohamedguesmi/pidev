/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.views;

import com.twilio.Twilio;
import com.twilio.http.TwilioRestClient;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;



/**
 *
 * @author Karim
 */
public class TwilioSms {

    public static final String ACCOUNT_SID = "AC4707cc7966382b7f54a75fe6f7de7b8c";
    public static final String AUTH_TOKEN = "813697f51dddc0765648a474a0df2bd1";

    public void sendSms(String body, String number) {
            Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

        Message.creator(new PhoneNumber(number),
        new PhoneNumber("+16125680687"), 
        body).create();
    }
}
