/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.views;

import gestionbiblio.Service.commandeService;
import gestionbiblio.entities.commande;
import gestionbiblio.entities.commande;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class ModifiercommandeController implements Initializable {

    @FXML
    private Button r;
    @FXML
    private TextField noml;
    @FXML
    private TextField nbp;
    @FXML
    private Button v;
    @FXML
    private DatePicker dateC;
    private static commande cr;
    
/**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        GestioncommandeController glc = new GestioncommandeController();
        commande lvr= glc.getL();
        noml.setText(lvr.getNomlivre());
        nbp.setText(String.valueOf(lvr.getNbp()));
        dateC.setValue(LocalDate.now());

         r.setOnAction(e->{  
            Parent root ;
         try {
             root=FXMLLoader.load(getClass().getResource("GestionCommande.fxml"));
             r.getScene().setRoot(root);
         } catch (IOException ex) {
             Logger.getLogger(ModifiercommandeController.class.getName()).log(Level.SEVERE, null, ex);
         }
            
             });  
         v.setOnAction(e->{
         Alert alert = new Alert(Alert.AlertType.WARNING);

                alert.setTitle("Error");
                  
         Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);

                alert.setTitle("Error");
                 
         String nl= noml.getText();
         String prx= nbp.getText();
         String cnt= dateC.getEditor().getText();
         

         String ch="";
         Boolean ok =true;
         int pr = -1;
         int test=Integer.parseInt(prx);
       
         if(!nl.matches("^[a-zA-Z]+$")){
             ch+="Vous devez entrer un nom valide!\n";
             ok=false;
         }
         if(!nl.matches("^[a-zA-Z]+$")){
             ch+="Vous devez entrer un nom livre valide!\n";
             ok=false;
         }
         if(!prx.matches("\\d+")||prx.length()==0||test>100){
             ch+="Vous devez entrer un nombre valide heures\n";
             ok=false;
         }

           
         else 
               pr = Integer.parseInt(prx);
           
           
           
         if(ok==true){
             commande commande1 = new commande(nl,pr,cnt);
             commande1.setId(lvr.getId());
             commandeService cs = new commandeService();
             try {
                 cs.updatecommande(commande1);
                 ch+="Modification effectué avec success!\n";
                alert1.setContentText(ch);
                alert1.show();
             } catch (SQLException ex) {
                 Logger.getLogger(ModifiercommandeController.class.getName()).log(Level.SEVERE, null, ex);
             }
         }
         else {
             alert.setContentText(ch);
                alert.show();
         }
        });
          r.setOnAction(e->{  
            Parent root ;
         try {
             root=FXMLLoader.load(getClass().getResource("Gestioncommande.fxml"));
             r.getScene().setRoot(root);
         } catch (IOException ex) {
             Logger.getLogger(ModifiercommandeController.class.getName()).log(Level.SEVERE, null, ex);
         }
            
             });  

         
    }    
    public commande getL() {
        return cr;
}
}
