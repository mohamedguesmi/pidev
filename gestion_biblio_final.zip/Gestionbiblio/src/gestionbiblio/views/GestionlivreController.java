/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.views;

import gestionbiblio.entities.livre;
import gestionbiblio.Service.livreService;
import gestionbiblio.entities.Images;
import static gestionbiblio.views.CommandController.l;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class GestionlivreController implements Initializable {

    @FXML
    private Button AjouterC;
    @FXML
    private Button AfficherC;
    @FXML
    private Button ModifierC;
    @FXML
    private Button SupprimerC;
    @FXML
    private TableView<livre> table;
    @FXML
    private TableColumn<livre, String> noml;
    @FXML
    private TableColumn<livre, String> noma;
    @FXML
    private TableColumn<livre, Integer> price;
    @FXML
    private TableColumn<livre, String> cont;
    @FXML
    private TableColumn<livre, Integer> quan;
     private static livre cr;
    @FXML
    private TableColumn<livre , String> images;
   
/**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        livreService cs= new livreService(); 
        ArrayList<livre> livre= new ArrayList<livre>();
        try {
            livre = (ArrayList<livre>) cs.readAll();
            
        } catch (SQLException ex) {
            Logger.getLogger(GestionlivreController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        ObservableList<livre> obs = FXCollections.observableArrayList(livre);

        table.setItems(obs);
        
        noml.setCellValueFactory(new PropertyValueFactory<>("nomlivre"));
        noma.setCellValueFactory(new PropertyValueFactory<>("auteurlivre"));
        price.setCellValueFactory(new PropertyValueFactory<>("prixlivre"));
        cont.setCellValueFactory(new PropertyValueFactory<>("contenu"));
        quan.setCellValueFactory(new PropertyValueFactory<>("quantitelivre"));
        images.setCellValueFactory(new PropertyValueFactory<>("imageLivre"));
        
        
        
        
        AjouterC.setOnAction(e -> {
            //(String id,String nom, String adresse, String prix, String surface,String capacite)

            try {
                Parent root;
                root = FXMLLoader.load(getClass().getResource("Ajouterlivre.fxml"));
                AjouterC.getScene().setRoot(root);

            } catch (IOException ex) {
                Logger.getLogger(AjouterlivreController.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
            SupprimerC.setOnAction(e -> {
            cr = table.getSelectionModel().getSelectedItem();
                if(cr != null)
                {
                cr = table.getSelectionModel().getSelectedItem();
                    try {
                        cs.deleteClasse((livre) cr);
                        Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
                         alert1.setContentText("Suppression effectuée avec succès!");
                           alert1.show();
                           
                    } catch (SQLException ex) {
                        Logger.getLogger(GestionlivreController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                livreService cr5= new livreService(); 
        ArrayList<livre> cla5= new ArrayList<livre>();
        try {
            cla5 = (ArrayList<livre>) cr5.readAll();
        } catch (SQLException ex) {
            Logger.getLogger(GestionlivreController.class.getName()).log(Level.SEVERE, null, ex);
        }
        ObservableList<livre> obs5 = FXCollections.observableArrayList(cla5);
       
        table.setItems(obs5);
        noml.setCellValueFactory(new PropertyValueFactory<>("nomlivre"));
        noma.setCellValueFactory(new PropertyValueFactory<>("auteurlivre"));
        price.setCellValueFactory(new PropertyValueFactory<>("prixlivre"));
        cont.setCellValueFactory(new PropertyValueFactory<>("contenu"));
        quan.setCellValueFactory(new PropertyValueFactory<>("quantitelivre"));
        images.setCellValueFactory(new PropertyValueFactory<>("imageLivre"));
                }
                   });

       
        ModifierC.setOnAction(e -> {
            //(String id,String nom, String adresse, String prix, String surface,String capacite)

            cr = table.getSelectionModel().getSelectedItem();
            if (!(cr == null)) {
                try {
                    Parent root;
                    root = FXMLLoader.load(getClass().getResource("Modifierlivre.fxml"));
                    ModifierC.getScene().setRoot(root);
                } catch (IOException ex) {
                    Logger.getLogger(GestionlivreController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
       
        
        
    }  
    
     public livre getL() {
        return cr;
}
}
