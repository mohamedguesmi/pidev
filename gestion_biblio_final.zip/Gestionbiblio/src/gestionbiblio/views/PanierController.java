/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.views;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import gestionbiblio.Service.livreService;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import gestionbiblio.entities.Panier;
import gestionbiblio.entities.livre;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class PanierController implements Initializable {

    @FXML
    private TableView<Panier> table;
    @FXML
    private TableColumn<Panier, livre> noml;
    /* @FXML
   private TableColumn<Panier, livre> prix;*/
    livreService cs = new livreService();
    @FXML
    private TableColumn<Panier, Integer> price;
    @FXML
    private Text prix;

    /*
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        ArrayList<Panier> panier = new ArrayList<Panier>();

        try {
            System.out.println("tryyyyyyyyyyyy");
            panier = (ArrayList<Panier>) cs.readAllFromPanier();

        } catch (SQLException ex) {
            Logger.getLogger(PanierController.class.getName()).log(Level.SEVERE, null, ex);
        }

        //System.out.println(commande);
        ObservableList<Panier> obs = FXCollections.observableArrayList(panier);
        table.setItems(obs);

        //prix.setCellValueFactory(new PropertyValueFactory<>("livre"));
        //price.setCellValueFactory(cellData -> cellData.getValue().getPrixTotale());
        noml.setCellValueFactory(new PropertyValueFactory<>("livre"));
        price.setCellValueFactory(new PropertyValueFactory<>("prixTotale"));
        float somme = 0;

        for (Panier p : panier) {
            somme = somme + p.getPrixTotale();

        }

        prix.setText("" + somme);

        // TODO
    }

    @FXML
    private void retour(ActionEvent event) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("IUser.fxml"));
            //
            Parent root1 = (Parent) fxmlLoader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root1));
            stage.show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setFILES(String Body, String Body1, String Body2, String Body3) {
        try {

            OutputStream file = new FileOutputStream(new File("text.pdf"));

            Document document = new Document();

            PdfWriter.getInstance(document, file);

            document.open();
            document.addTitle("Ticket");

            com.itextpdf.text.Image img;
            //img = com.itextpdf.text.Image.getInstance("C:/Users/loume78/Documents/NetBeansProjects/Louay_project/src/com/pidev/affiches/louay.jpg");
            //com.itextpdf.text.Image.getInstance(img);
            //document.add(img);
            document.add(new Paragraph("                    "));
            document.add(new Paragraph("                    "));
            document.add(new Paragraph("                    "));
            document.add(new Paragraph("                    "));
            document.add(new Paragraph(Body));
            document.add(new Paragraph(Body1));
            document.add(new Paragraph(Body2));
            document.add(new Paragraph(Body3));
            document.close();
            file.close();

        } catch (Exception e) {

            e.printStackTrace();

        }

    }

    public void btnPDF(String Body, String Body1, String Body2, String Body3) throws IOException, SQLException {
        //User userTest = new User(102, "Louay", "Yahyaoui", "louay@esprit.tn", "louay", "oussema", "male", "28-08-1992", 234223878, "SimpleUtilisateur", "Comedie", "hahaha", 5000);
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        Button button2 = new Button();
        button2.setStyle("-fx-background-color: #00ff00");
        alert.setTitle("PDF ");
        alert.setContentText("Realisation avec succés !  vous voulez exporter votre Commande en PDF ?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            setFILES(Body, Body1, Body2, Body3);

        } else {

        }
    }

    @FXML
    private void ConfirmerAction(ActionEvent event) throws SQLException {
        
        livreService ls = new livreService();
        List<Panier> arr = new ArrayList<>();
        arr = ls.readAllFromPanier();
        String Body = "";
        float prixTot = 0;
        for(Panier p: arr) {
            System.err.println("this is test");
            System.out.println(p.getPrixTotale());
             prixTot += p.getPrixTotale();
        }
        
         for(Panier p: arr) {
             Body = "id :"+ p.getId() + "  prix : "+ prixTot;
            
        }

//        TwilioSms twilio = new TwilioSms();
//        twilio.sendSms("Participation avec succés Mr--Nizar-Mahmoudi", "+21658080602");

        
        String Body1 = "Au sein de notre Competition sous le Titre ----";
        String Body2 = "Voici votre Mot de passe pour accédé à ----";
        String Body3 = "Mot de passe =====> : ";
        try {
            btnPDF(Body, Body1, Body2, Body3);
        } catch (IOException ex) {
            Logger.getLogger(PanierController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
