/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionbiblio.views;

import gestionbiblio.Service.commandeService;
import gestionbiblio.entities.commande;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author ASUS
 */
public class AjoutercommandeController implements Initializable {

    @FXML
    private Button r;
    @FXML
    private TextField nomL;
    @FXML
    private TextField nbp;
    private Button a;
    @FXML
    private DatePicker dateC;
    @FXML
    private Button k;
    
     
  /**
     * Initializes the controller class.
     
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        k.setOnAction(e-> {
            //Local(String nom, String adresse, float prix,float surface,int capacite)
            Alert alert = new Alert(Alert.AlertType.WARNING);
            
            alert.setTitle("Error");
            Alert alert1 = new Alert(Alert.AlertType.CONFIRMATION);
            
            alert.setTitle("Success");
            
            String n= nomL.getText();
            String ne= nbp.getText();
            String dc= dateC.getEditor().getText();
        
            String ch="";
            Boolean ok =true;
            int pr = -1;
            
            int test=Integer.parseInt(ne);
            if(!n.matches("^[a-zA-Z]+$")){
                ch+="Vous devez entrer un nom valide!\n";
                ok=false;
            }
            if(!ne.matches("\\d+")||ne.length()==0){
                ch+="Vous devez entrer un nbp valide!\n";
                ok=false;
            }
            if(!n.matches("^[a-zA-Z]+$")){
                ch+="Vous devez entrer un nom d auteur valide\n";
                ok=false;
            }
            else {
                pr = Integer.parseInt(ne);
                
            }
            if(ok==true){
                commande commande1 = new commande(n,pr,dc);
                commandeService cs = new commandeService();
                try {
                    cs.ajoutercommande(commande1);
                    ch+="Ajout effectué avec success!\n";
                    alert1.setContentText(ch);
                    alert1.show();
                    
                } catch (SQLException ex) {
                    Logger.getLogger(AjouterlivreController.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            else {
                alert.setContentText(ch);
                alert.show();
            }
        });
        r.setOnAction(e->{  
            Parent root ;
         try {
             root=FXMLLoader.load(getClass().getResource("Gestioncommande.fxml"));
             r.getScene().setRoot(root);
         } catch (IOException ex) {
             Logger.getLogger(ModifierlivreController.class.getName()).log(Level.SEVERE, null, ex);
         }
            
             });  
    }    
    
}
